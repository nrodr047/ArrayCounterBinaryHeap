
/**************************************************************
 Purpose/Description: This program uses a binary min heap and replaces a old
key with a new key and restores the min-heap property after the keys have been
exchanged.
 Panther ID: 2919853
 Certification:
 I hereby certify that this work is my own and none of it is the work of
 any other person.


2a. When considering a binary min heap, none of the traversals would sort the
output. In a binary min heap, the root must be smaller than all it's children.

Let the root of the binary min heap be 1, let the 
left child be 6 and the right child be 2. 

In this instance, a pre-order traversal goes from the root, left, right. This 
would result in 1, 6, 2, which is not a sorted output.

Given the same inputs, a inorder traversal would also not be sorted. A inorder
traversal reads the heap from left, root, right. Therefore, the output would be
6,1,2, which is not sorted.

For a postorder traversal given the same inputs, the binary min heap would still
not be sorted. Postorder traversal sorts from left, right, root. Therefore, the
output would be 6,2,1, which is not sorted.


2b. Algorithm for finding all nodes less than some value X in a binary min heap:

findKeys(int x, int position, int heap[], int count)
if position > count 
return;
if heap[position] >= x //starting from the root
return;

findKeys(x, left(position), heap, count)
findKeys(x, right(position), heap, count) //recursive calls for each node



2f. The time complexity of the replaceKey() method is O(N) because it uses a 
while loop to find the old key in the array.
 **************************************************************/
package binaryheap;

/**
 *Tester class
 */
public class BinaryHeap
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int[] arry = {4, 6, 7, 32, 19, 64, 26, 99, 42, 54, 28};
        int oldKey = 54;
        int newKey = 2;
        MinHeap bh = new MinHeap(arry, oldKey, newKey);
    }
    
}
