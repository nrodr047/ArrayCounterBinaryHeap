
package arraycounter;
import java.util.Scanner;
       

/**
 *Class counts how many instances of integers can be found within a specified 
 * range given an array of integers.
 * @author Natalie
 */
public class CountSort
{
    private int [] arr;
    private int max;
    private int low;
    private int high;
    
    /**
     * Constructor.
     * @param a array of integers
     * @param userMax the largest number in the array
     * @param userLow the lower limit of the range
     * @param userHigh the highest limit of the range
     */
    public CountSort(int[] a, int userMax, int userLow, int userHigh){
        arr = a;
        max = userMax;
        low = userLow;
        high = userHigh;
    }
    
    /**
     * Method uses a counter to find how many integers the array contains that
     * are within the given range.
     */
    public void count(){
        int counter[] = new int[max];
        int finalCount = 0;
        
        //initializes all elements in the counter to zero.
        for(int i = 0; i < arr.length; i++){
            counter[i] = 0;
        }
        
        //stores the count of each number in each position in the array 
        for(int i = 0; i< arr.length; i++){
            counter[arr[i]-1]++;
        }
        
        //calculates the number of integers in the array between
        //the specified range and assigns it to the final count.
        for(int i = low; i <= high; i++){
            finalCount += counter[i-1];
        }
        
        System.out.println("The total number in range (" + low + ".." + high +
                ") is: " + finalCount);
    }
    
    
}
