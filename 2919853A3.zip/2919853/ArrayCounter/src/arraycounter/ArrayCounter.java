/**************************************************************
 Purpose/Description: The program counts how many integers there are within a
 * given range from an unsorted array (with possible duplicates).
 Panther ID: 2919853
 Certification:
 I hereby certify that this work is my own and none of it is the work of
 any other person.
 **************************************************************/ 
package arraycounter;


/**
 *Tester class.
 * @author Natalie
 */
public class ArrayCounter
{

    /**
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int [ ] a = {3, 8, 2, 4, 1, 9, 11, 4, 15}; //input array         
        int k = 15;    // max element in a 
        int left = 2;  // lower value in range          
        int right = 9; // upper value in range Output: 
        
        
        CountSort counter = new CountSort(a, k, left, right);
        counter.count();
        
        
    }
    
}
